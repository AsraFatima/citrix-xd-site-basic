#
# DeliveryController.ps1
#
configuration DeliveryController 
{ 
   param 
   ( 
		# Credentials and domain
        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [String]$DomainController,

        [Parameter(Mandatory)]
        [String]$DomainControllerIp,
	    
	    # Delegated servers
        [Parameter(Mandatory)]
        [String]$SQLServer,

        [Parameter(Mandatory)]
        [String]$SQLServerInstance,

        [Parameter(Mandatory)]
        [String]$LicenseServer,

        [Parameter(Mandatory)]
        [String]$NetScalerIP,
	    
	    # StoreFront
        [Parameter(Mandatory)]
        [String]$StoreFront,

        [Parameter(Mandatory)]
        [String]$VirtualServerName,

        [Parameter(Mandatory)]
        [Int]$VirtualServerPort,

        [Parameter(Mandatory)]
        [Int]$ForwardServerPort,

        [Parameter(Mandatory)]
        [String]$StoreFrontGatewayName,

        [Parameter(Mandatory)]
        [String]$EmailAddress,

        [Parameter(Mandatory)]
        [String]$ACMEServer,

        [Parameter(Mandatory)]
        [String]$GatewayFQDN,

        [Parameter(Mandatory)]
        [String]$DeploymentFQDN,

        [Parameter(Mandatory)]
        [String]$ThemeUri,

        [Parameter(Mandatory)]
        [String]$HTML5Mode,

        [Parameter(Mandatory)]
        [Hashtable[]]$AppGroups,

        [Parameter(Mandatory)]
        [String]$License,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$CertificatePassword,
	     
	    # Delivery controller
        [Parameter(Mandatory)]
        [String]$DeliveryController,

        [Parameter(Mandatory)]
        [String]$SiteName,

        [Int]$RetryCount = 50,
        [Int]$RetryIntervalSec = 60
    ) 

    Import-DscResource -ModuleName PSDesiredStateConfiguration -ModuleVersion 1.1
    Import-DscResource -ModuleName xActiveDirectory, xComputerManagement, CitrixXenDesktopAutomation, xCertificate, xWebAdministration, CitrixNetscaler, CitrixMarketplace, ACMEPowerShell, ACMECertificate, xSmbShare, xNetworking
 
    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    
	$Interface=Get-NetAdapter|Where Name -Like "Ethernet*"|Select-Object -First 1
    $InterfaceAlias=$($Interface.Name)

    $siteDatabaseName = "Citrix" + $SiteName + "Site"
    $monitoringDatabaseName = "Citrix" + $SiteName + "Monitoring"
    $loggingDatabaseName = "Citrix" + $SiteName + "Logging"

	$iisPath = "C:\\inetpub\\wwwroot"
	$certFile = "C:\Vault\cert.pem"
	$keyFile = "C:\Vault\key.pem"
	$pairFile = "C:\Vault\pair.pem"
	$vaultPath = "C:\Vault"

    Node localhost
    {
        LocalConfigurationManager 
        { 
            RebootNodeIfNeeded = $true
			ConfigurationMode = "ApplyOnly"
        } 

        WindowsFeature ADPowershell
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        } 

        WindowsFeature InstallWebServer
        {
            Name = "Web-Server"
            Ensure = "Present"
            DependsOn = "[WindowsFeature]ADPowershell"
        }
        
        WindowsFeature InstallWebAsp
        {
            Name = "Web-Asp-Net45"
            Ensure = "Present"
            DependsOn = "[WindowsFeature]InstallWebServer"
        }

        WindowsFeature InstallWebConsole
        {
            Name = "Web-Mgmt-Console"
            Ensure = "Present"
            DependsOn = "[WindowsFeature]InstallWebAsp"
        }

		Citrix_MarketplaceConditionWait DomainCondition 
        { 
            Condition = "Domain"
			Machine = $DomainControllerIp
            PsDscRunAsCredential = $Admincreds
            DependsOn = "[WindowsFeature]InstallWebConsole" 
        }  

		Script ResetAdapter
        { 
			GetScript = { @{} }
			SetScript = { Start-Sleep -Seconds 180; ipconfig /release; ipconfig /renew; ipconfig /flushdns; }
			TestScript = { $false }
            DependsOn = "[Citrix_MarketplaceConditionWait]DomainCondition" 
        }  

		xWaitForADDomain WaitForDomain 
        { 
            DomainName = $DomainName 
            DomainUserCredential= $Admincreds
            RetryCount = $RetryCount 
            RetryIntervalSec = $RetryIntervalSec
            DependsOn = "[Script]ResetAdapter" 
        }

        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCreds
            DependsOn = "[xWaitForADDomain]WaitForDomain" 
        }

        xCertReq SSLCert
        {
            CARootName = 'DomainCA'
            CAServerFQDN = $DomainController
            Subject = $DeliveryController
            AutoRenew = $true
            Credential = $DomainCreds
            DependsOn = "[xComputer]DomainJoin"
        }

        xWebSite DefaultWebSite {
            Name = 'Default Web Site';
            PhysicalPath = 'C:\inetpub\wwwroot';
            BindingInfo = @(
                MSFT_xWebBindingInformation  { Protocol = 'HTTPS'; Port = 443; CertificateThumbprint = $DeliveryController; CertificateStoreName = 'My'; }
                MSFT_xWebBindingInformation  { Protocol = 'HTTP'; Port = 80; }
            )
            DependsOn = '[xCertReq]SSLCert';
        }
        
        Citrix_XenDesktopDatabase CreateSiteDatabase
        {
            SiteName = $SiteName
            DatabaseClass = "Site"			
            DatabaseServer = $SQLServer
            DatabaseServerInstance = $SQLServerInstance
            DatabaseName = $siteDatabaseName
            DatabaseCredential = $DomainCreds
            PsDscRunAsCredential = $DomainCreds
            DependsOn = "[xWebSite]DefaultWebSite"
        }

        Citrix_XenDesktopDatabase CreateLoggingDatabase
        {
            SiteName = $SiteName
            DatabaseClass = "Logging"			
            DatabaseServer = $SQLServer
            DatabaseServerInstance = $SQLServerInstance
            DatabaseName = $loggingDatabaseName
            DatabaseCredential = $DomainCreds
            PsDscRunAsCredential = $DomainCreds
            DependsOn = "[Citrix_XenDesktopDatabase]CreateSiteDatabase" 
        }

        Citrix_XenDesktopDatabase CreateMonitorDatabase
        {
            SiteName = $SiteName
            DatabaseClass = "Monitor"			
            DatabaseServer = $SQLServer
            DatabaseServerInstance = $SQLServerInstance
            DatabaseName = $monitoringDatabaseName
            DatabaseCredential = $DomainCreds
            PsDscRunAsCredential = $DomainCreds
            DependsOn = "[Citrix_XenDesktopDatabase]CreateLoggingDatabase" 
        }

        Citrix_XenDesktopSite CreateSite
        {
            DatabaseServer = $SQLServer
            DatabaseServerInstance = $SQLServerInstance
            UserToMakeAdmin = $DomainCreds.UserName
            XenDesktopController = "localhost:80"
            SiteName = $SiteName
            LicenseServer = $LicenseServer
            LicenseServerPort = 27000
            LoggingDatabaseName = $loggingDatabaseName
            MonitoringDatabaseName = $monitoringDatabaseName
            SiteDatabaseName = $siteDatabaseName
            Ensure = "Present"
            DependsOn = "[Citrix_XenDesktopDatabase]CreateMonitorDatabase" 
        }

		Citrix_XenDesktopDirector Director
        {
            XenDesktopController = $DeliveryController
            PsDscRunAsCredential = $DomainCreds
            DependsOn = "[Citrix_XenDesktopSite]CreateSite" 
        }

		Citrix_MarketplaceDomain Domain
        { 
            DeploymentFQDN = $DeploymentFQDN
            GatewayFQDN = $GatewayFQDN
			EmailAddress = $EmailAddress
			IisRoot = $iisPath
            DependsOn = "[Citrix_XenDesktopDirector]Director" 
        }
		
	ACME_CertificateRequest CertRequest
        { 
            ACMEServer = $AcmeServer
            CommonName = $GatewayFQDN
            EmailAddress = $EmailAddress
            CertificatePassword = $CertificatePassword
            VaultPath = $vaultPath
            CertPath = $certFile
            KeyPath = $keyFile
			PairPath = $pairFile
            IISPath = $iisPath
            DependsOn = "[Citrix_MarketplaceDomain]Domain" 
        }              
       

        Citrix_NetscalerLocalFile Certificate 
        {
            Filename = "/nsconfig/ssl/certificate.pem"
            NetScalerIP = $NetScalerIP
            NetscalerCredential = $Admincreds
            LocalPath = $pairFile
            Ensure = "Present"
            DependsOn = "[ACME_CertificateRequest]CertRequest"
        }

		Citrix_NetscalerConfigureXD NSConfig 
        {
            NetScalerIP = $NetScalerIP
            NetscalerCredential = $Admincreds
            DomainCredential = $Admincreds
            CertificatePassword = $CertificatePassword
            DomainName = $DomainName
            DomainController= $DomainControllerIp
            StorefrontServer = $StoreFront
            DeliveryController = $DeliveryController
            VirtualServerName = $VirtualServerName
            VirtualServerPort = $VirtualServerPort
            ForwardServerPort = $ForwardServerPort
            DependsOn = "[Citrix_NetscalerLocalFile]Certificate"
        }

        Citrix_XenDesktopStorefront Storefront
        {
            XenDesktopController = $DeliveryController
            StorefrontServer = $StoreFront
            NetScalerIp = $NetScalerIP
			DomainName = $DomainName
            FQDN = $GatewayFQDN
            HTML5Mode = $HTML5Mode
            GatewayName = $StoreFrontGatewayName
			AppGroups = $AppGroups | ConvertTo-Json
            SiteName = $SiteName
            Transport = "HTTPS"
            Port = 443
            PsDscRunAsCredential = $DomainCreds
            DependsOn = "[Citrix_NetscalerConfigureXD]NSConfig" 
        }

		Citrix_MarketplaceConditionSet ControllerCondition 
        { 
            Condition = "Controller"
            DependsOn = '[Citrix_XenDesktopStorefront]Storefront'
        }  

		if($ACMEServer -match "staging")
		{
			Script StagingCert
	        {
				SetScript = {
					$encodedCer = "MIIDETCCAfmgAwIBAgIJAJzxkS6o1QkIMA0GCSqGSIb3DQEBCwUAMB8xHTAbBgNVBAMMFGhhcHB5IGhhY2tlciBmYWtlIENBMB4XDTE1MDQwNzIzNTAzOFoXDTI1MDQwNDIzNTAzOFowHzEdMBsGA1UEAwwUaGFwcHkgaGFja2VyIGZha2UgQ0EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDCCkd5mgXFErJ3F2M0E9dw+Ta/md5i8TDId01HberAApqmydG7UZYF3zLTSzNjlNSOmtybvrSGUnZ9r9tSQcL8VM6WUOM8tnIpiIjEA2QkBycMwvRmZ/B2ltPdYs/R9BqNwO1g18GDZrHSzUYtNKNeFI6Glamj7GK2Vr0SmiEamlNIR5ktAFsEErzf/d4jCF7sosMsJpMCm1p58QkP4LHLShVLXDa8BMfVoI+ipYcA08iNUFkgW8VWDclIDxcysa0psDDtMjX3+4aPkE/cefmP+1xOfUuDHOGV8XFynsP4EpTfVOZr0/g9gYQ7ZArqXX7GTQkFqduwPm/w5qxSPTarAgMBAAGjUDBOMB0GA1UdDgQWBBT7eE8S+WAVgyyfF380GbMuNupBiTAfBgNVHSMEGDAWgBT7eE8S+WAVgyyfF380GbMuNupBiTAMBgNVHRMEBTADAQH/MA0GCSqGSIb3DQEBCwUAA4IBAQAd9Da+Zv+TjMv7NTAmliqnWHY6d3UxEZN3hFEJ58IQVHbBZVZdW7zhRktBvR05Kweac0HJeK91TKmzvXl21IXLvh0gcNLU/uweD3no/snfdB4OoFompljThmglzBqiqWoKBJQrLCA8w5UB+ReomRYd/EYXF/6TAfzm6hr//Xt5mPiUHPdvYt75lMAovRxLSbF8TSQ6b7BYxISWjPgFASNNqJNHEItWsmQMtAjjwzb9cs01XH9pChVAWn9LoeMKa+SlHSYrWG93+EcrIH/dGU76uNOiaDzBSKvaehG53h25MHuO1anNICJvZovWrFo4Uv1EnkKJm3vJFe50eJGhEKlx"
					$binaryCer = [Convert]::FromBase64String($encodedCer)

					$pfx = new-object System.Security.Cryptography.X509Certificates.X509Certificate2
					$pfx.import($binaryCer)

					$store = new-object System.Security.Cryptography.X509Certificates.X509Store(
						[System.Security.Cryptography.X509Certificates.StoreName]::Root,
						"localmachine"
					)

					$store.open("MaxAllowed")
					$store.add($pfx)
					$store.Close()
				}
				TestScript = { 
					Test-Path "Cert:\localmachine\Root\5F5968E72FFD87450DD50E5EE96A1B793F110D46"
				}
				GetScript = { 
					return @{ Key = "Test-Path Cert:\localmachine\Root\5F5968E72FFD87450DD50E5EE96A1B793F110D46" }
				}          
			}
		}
    }
} 
